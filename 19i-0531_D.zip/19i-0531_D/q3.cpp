int **MatrixMul(int **MatrixA,int rowsA,int colsA,int** MatrixB,int rowsB,int colsB)
{
    int **Final_Array=new int*[rowsA];
    for(int i=0;i<rowsA;i++)
    {
        Final_Array[i]=new int[colsB];
    }
    for(int i=0;i<rowsA;i++)
    {
        for(int j=0;j<colsB;j++)
        {
            Final_Array[i][j]=0;
        }
    }
    if(colsA==rowsB)
    {
            for(int i=0;i<rowsA;i++)
            {
                for(int j=0;j<colsB;j++)
                {
                    for(int k=0;k<colsA;k++)
                    {
                        //Final_Array[i][j]=Final_Array[i][j]+(MatrixA[i][k]+Matrix[k][i]);
                        Final_Array[i][j]+=(MatrixA[i][k]*MatrixB[k][j]);
                    }
                }
            }
    }
    return Final_Array;
}
int **MatrixAdd(int **MatrixA,int rowsA,int colsA,int **MatrixB,int rowsB,int colsB)
{
    int **FINAL_ARRAY=new int*[rowsA];
    for(int i=0;i<rowsA;i++)
    {
       FINAL_ARRAY[i]=new int[colsA];
    }
    for(int i=0;i<rowsA;i++)
    {
        for(int j=0;j<colsA;j++)
        {
            FINAL_ARRAY[i][j]=0;
        }
    }
    if(rowsA==rowsB && colsA==colsB)
    {
      for(int i=0;i<rowsA;i++)
        {
            for(int j=0;j<colsA;j++)
            {
                FINAL_ARRAY[i][j]=MatrixA[i][j]+MatrixB[i][j];
            }
        }
    }
    return FINAL_ARRAY;
}
int **MatrixSub(int **MatrixA,int rowsA,int colsA,int** MatrixB,int rowsB, int colsB)
{
     int **FINAL_ARRAY=new int*[rowsA];
    for(int i=0;i<rowsA;i++)
    {
       FINAL_ARRAY[i]=new int[colsA];
    }
    for(int i=0;i<rowsA;i++)
    {
        for(int j=0;j<colsA;j++)
        {
            FINAL_ARRAY[i][j]=0;
        }
    }
    if(rowsA==rowsB && colsA==colsB)
    {
      for(int i=0;i<rowsA;i++)
        {
            for(int j=0;j<colsA;j++)
            {
                FINAL_ARRAY[i][j]=MatrixA[i][j]-MatrixB[i][j];
            }
        }
    }
    return FINAL_ARRAY;
}
int **MatrixTranspose(int **Matrix,int rows,int cols)
{
    int **FINAL_ARRAY=new int*[cols];
    for(int i=0;i<cols;i++)
    {
        FINAL_ARRAY[i]=new int[rows];
    }
    for(int i=0;i<cols;i++)
    {
        for(int j=0;j<rows;j++)
        {
            FINAL_ARRAY[i][j]=0;
        }
    }
    for(int i=0;i<rows;i++)
    {
        for(int j=0;j<cols;j++)
        {
            FINAL_ARRAY[j][i]=Matrix[i][j];
        }
    }
    return FINAL_ARRAY;
}
int **MatrixRotate(int **Matrix,int rows,int cols)
{
        int **SEMI_FINAL=new int*[cols];
        for(int j=0;j<cols;j++)
        {
            SEMI_FINAL[j]=new int[rows];
        }
        for(int i=0;i<rows;i++)
        {
            for(int j=0;j<cols;j++)
            {
                SEMI_FINAL[j][i]=0;
            }
        }
        for(int i=0;i<rows;i++)
        {
            for(int j=0;j<cols;j++)
            {
                SEMI_FINAL[j][i]=Matrix[i][j];
            }
        }
       /* cout<<endl;
        for(int i=0;i<rows;i++)
        {
            for(int j=0;j<cols;j++)
            {
                cout<<SEMI_FINAL[i][j]<<" ";
            }
            cout<<endl;
        }*/
        int **FINAL_ARRAY=new int*[cols];
        for(int i=0;i<cols;i++)
        {
           FINAL_ARRAY[i]=new int[rows];
        }
        for(int i=0;i<cols;i++)
        {
            for(int j=0;j<rows;j++)
            {
                FINAL_ARRAY[i][j]=SEMI_FINAL[i][rows-1-j];
            }
        }
        for(int i=0;i<cols;i++)
        delete []SEMI_FINAL[i];
        delete []SEMI_FINAL;
        return FINAL_ARRAY;
}

int MatrixDet( int ** Matrix , int rows , int cols )
{
    int DETERMINENT=0;
    if(rows==cols)
    {
        if(rows==1)//1x1 arrays Determinent is element itself because of having only 1 element
        {
            return Matrix[rows][cols];
        }
        if(rows==2)
        {
            DETERMINENT=(Matrix[0][0]*Matrix[1][1])-(Matrix[0][1]*Matrix[1][0]);//Final stage of smaller unit of matrix expansion if N>2
            return DETERMINENT;
        }
        else if(rows>2)
        {
            int **FINAL_ARRAY = new int*[rows];//Process to create 2D array using DMA
            for(int i=0;i<rows;i++)//Setting Cols.
            {
                FINAL_ARRAY[i]=new int[cols];
            }
            for(int i=0;i<cols;i++)//Assigning zero for reduction of garbage
            {
                for(int j=0;j<cols;j++)
                {
                    FINAL_ARRAY[i][j]=0;
                }
            }
            int yaxis=0;//For storing respectively
            int xaxis=0;//For storing respectively
            for(int i=0;i<cols;i++)
            {
                yaxis=0;//For storing respectively,zero assigned on every this loops iteration
                for(int j=1;j<cols;j++)
                {
                    //For storing respectively,Zero assigned on every iteration of this loop
                    xaxis=0;
                    for(int k=0;k<cols;k++)
                    {
                        if(k==i)//Ignoring Cols and rows related to i-th cols and when detected increment on k
                        {
                            k++;
                        }
                        FINAL_ARRAY[yaxis][xaxis]=Matrix[j][k];
                        xaxis++;
                    }
                yaxis++;
                }
            /*As long as we want 3x3 matrix Determinent we can just do here without recusrion But Without Recusrion It is complicated to know
             Determinent of any NxN matrix So here We made a program when rows-1 will pass then it will do recusrsive operation and it is expanding actually 3x3 to smaller parts of 2x2 if 2x2 matrix passed then
             simple condition rows==2 at start and if matrix is NXN where N>3 THen this recusive part will expand to N-1xN-1 size matrix and further till approaches to 2x2 and then this is actually the
             tipping point and returns will excute in order and finally Final Value will be generated*/
           DETERMINENT+=pow(-1,i)*Matrix[0][i]*(MatrixDet(FINAL_ARRAY,rows-1,rows-1));
            }
        }
    }
    return DETERMINENT;
}

float** MatrixInverse ( int** Matrix , int rows , int cols )
{
	int Det=0;
    float **FINAL_ARRAY = new float*[rows];
    for(int i=0;i<rows;i++)
    {
        FINAL_ARRAY[i]= new float[cols];
    }
        if(rows==1)
        {
	    FINAL_ARRAY[0][0] = Matrix[0][0];
            return FINAL_ARRAY;
        }
        else if(rows==2)
        {
	    Det = (Matrix[0][0]*Matrix[1][1]-(Matrix[0][1]*Matrix[1][0]));
            int **SUBJECT_COL2=new int*[rows];
            for(int i=0;i<rows;i++)
            {
                SUBJECT_COL2[i]=new int[cols];
            }
            SUBJECT_COL2[0][0]=Matrix[1][1];
            SUBJECT_COL2[1][1]=Matrix[0][0];
            SUBJECT_COL2[0][1]=(-1)*Matrix[0][1];
            SUBJECT_COL2[1][0]=(-1)*Matrix[1][0];
            for(int i=0;i<rows;i++)
            {
                for(int j=0;j<cols;j++)
                {
                    FINAL_ARRAY[i][j]=SUBJECT_COL2[i][j]/float(Det);
                }
            }
            return FINAL_ARRAY;
        }
}
