int Strlen(char *s1)
{
    int LENGTH=0;
    for(int i=0;i<=LENGTH;i++)
    {
        if(s1[i]=='\0')
        {
            i=LENGTH+1;
        }
        else
        {
            LENGTH++;
        }
    }
    return LENGTH;
}
char *Strcpy(char *s1,const char *s2)
{
    int LENGTH = 0;
    for(int i=0;i<=LENGTH;i++)
        {
            if(s1[i]=='\0')
            {
                i=LENGTH+1;
            }
            else
            LENGTH++;
        }
    int LENGTH1 = 0;
    for(int i=0;i<=LENGTH1;i++)
        {
            if(s2[i]=='\0')
            {
                i=LENGTH1+1;
            }
            else
            LENGTH1++;
        }
if(LENGTH>=LENGTH1)
{
    for(int i=0;i<=LENGTH1;i++)
        {
            if(i<LENGTH)
            s1[i]=s2[i];
            else
            s1[i]='\0';
        }
	 return s1;

}
else
{
	s1="";
}
return s1;

}
char *Strncpy(char *s1,const char *s2,int n)
{
    int LENGTH=0;
    int LENGTH1=0;
    while(s1[LENGTH]!='\0')
   {
       LENGTH++;
   }
   while(s2[LENGTH1]!='\0')
   {
       LENGTH1++;
   }
    if(n<LENGTH)
    {
        if(n>LENGTH1)
        {
            for(int i=0;i<LENGTH1;i++)
            {
               s1[i]=s2[i];
            }
            return s1;
        }
        else
        {

            for(int i=0;i<n;i++)
            {
               s1[i]=s2[i];
            }
            return s1;
        }
    }
    else
    {
        s1="";
        return s1;
    }
}
char *StrCat(char *s1,const char *s2)
{
    int LENGTH1=0;
    int S1_NULL;
    for(int i=0;i<=LENGTH1;i++)
        {
            if(s1[i]=='\0')
                {
                    S1_NULL=i;
                }
            else
            {
                LENGTH1++;
            }

        }
    int LENGTH2=0;
    for(int i=0;i<=LENGTH2;i++)
        {
            if(s2[i]=='\0')
                {
                    i=LENGTH2+1;
                }
            else
                {
                     LENGTH2++;
                }

        }
    for(int i=0;i<=LENGTH2;i++)
        {
            if(i<LENGTH2){
            s1[S1_NULL+i]=s2[i];
            }
            else
            {
                s1[S1_NULL+i]='\0';
            }

        }
    return s1;
}
char *StrnCat(char *s1,const char *s2,int n)
{
    int LENGTH1=0;
    int S1_NULL;
    for(int i=0;i<=LENGTH1;i++)
        {
            if(s1[i]=='\0')
                {
                    S1_NULL=i;
                }
            else
            {
                LENGTH1++;
            }

        }
    for(int i=0;i<=n;i++)
        {
            if(i<n){
            s1[S1_NULL+i]=s2[i];
            }
            else
            {
                s1[S1_NULL+i]='\0';
            }

        }
    return s1;
}
int StrCmp(const char *s1,const char *s2)
{
    int LEN=0;
    for(int i=0;i<=LEN;i++)
    {
        if(s1[i]=='\0')
        {
            i=LEN+1;
        }
        else
        {
            LEN++;
        }

    }
    int LEN1=0;
    for(int i=0;i<=LEN1;i++)
    {
        if(s2[i]=='\0')
        {
            i=LEN1+1;
        }
        else
        {
            LEN1++;
        }

    }
    int Large=0;
    if(LEN>LEN1)
    {
        Large=LEN;
    }
    else if(LEN<LEN1)
    {
        Large=LEN1;
    }
    else
     Large=LEN1;
     for(int i=0;i<Large;i++)
     {

         if(s1[i]!=s2[i])
         {
            if(s1[i]>s2[i])
            {
                return 1;
            }
            else
                return -1;
         }

     }
     return 0;

}
int StrnCmp(const char *s1,const char *s2,int n)
{
    int LEN=0;
    for(int i=0;i<=LEN;i++)
    {
        if(s1[i]=='\0')
        {
            i=LEN+1;
        }
        else
        {
            LEN++;
        }

    }
    int LEN1=0;
    for(int i=0;i<=LEN1;i++)
    {
        if(s2[i]=='\0')
        {
            i=LEN1+1;
        }
        else
        {
            LEN1++;
        }

    }
    int Large=n;
     for(int i=0;i<Large;i++)
     {

         if(s1[i]!=s2[i])
         {
            if(s1[i]>s2[i])
            {
                return 1;
            }
            else
                return -1;
         }

     }
     return 0;

}
char **StrTok(char *s1,const char s2)
{
    int S1_Length=0;
    int Xcount=0;
   for(int i=0;i<=S1_Length;i++)
    {
        if(s1[i]=='\0')
        {
            i=S1_Length+1;
        }

        else if(s1[i]==s2)
        {
            Xcount++;
            S1_Length++;
        }
        else
        {
            S1_Length++;
        }

    }
    Xcount++;

    int *Sizes=new int[Xcount];

    for(int i=0;i<Xcount;i++){
        Sizes[i]=0;
    }

    int repeat=0;

    for(int i=0;i<=Xcount;)
    {
        if(s1[repeat]==s2){
            i++;
            repeat++;
        }

        if(s1[repeat]=='\0'){
            i=Xcount+1;
        }

        else{
            repeat++;
            Sizes[i]++;}
    }

    char **Token=new char*[Xcount];

    for(int i=0;i<Xcount;i++)
    {
         Token[i]=new char[Sizes[i]+1];
    }

    /*for(int i=0;i<Xcount;i++){
        for(int j=0;j<Sizes[i]+1;j++){
            Token[i][j]='0';
        }

    }*/

    int length1=0;
    int j=0;

    S1_Length+=1;

    for(int i=0;i<S1_Length;i++,j++)
    {
        if(s1[i]==s2)
        {
            //cout<<"Before NULL = "<<Token[length1][j]<<endl;
            Token[length1][j]='\0';
            //cout<<"After NULL = "<<Token[length1][j]<<endl;
            length1++;
            j=-1;
        }
        else
        {
            Token[length1][j]=s1[i];
            //cout<<Token[length1][j];
        }
    }
    return Token;
}
int StrFind(char *s1,char *s2)
{
   int index=-19;
   int LENGTH=0,LENGTH2=0;
   for(int i=0;i<=LENGTH;i++)
   {
      if(s1[i]=='\0')
      {
          i=LENGTH+1;
      }
      else
      LENGTH++;
   }
    for(int i=0;i<=LENGTH2;i++)
   {
      if(s2[i]=='\0')
      {
          i=LENGTH2+1;
      }
      else
      LENGTH2++;
   }
   bool complete=true;
   int attempt=0;
   if(LENGTH>=LENGTH2)
   {
       for(int i=0;i<LENGTH;i++)
       {
           if(s1[i]==s2[0])
           {
               attempt++;
               for(int j=1;j<=LENGTH2;j++)
               {
                   if(s1[i+j]!=s2[j] && j<LENGTH2)
                   {
                       complete=false;
                       attempt=0;
                       index=-1;
                   }
                   else if(j==LENGTH2 && complete==true)
                   {
                       index=i;
                   }
                    /*if((s1[i+j+1]!='\0'&& s1[i+j+1]!=' ') && j==LENGTH2-1)
                   {
                       complete=false;
                       attempt=0;
                       index=-1;
                   }*/
               }
           }
           if(complete==true && index!=-19 && index!=-1 && attempt>0)
           {
               return index;
           }
           if(i==LENGTH-1 && attempt==0)
           {
               return -1;
           }
       }
   }
   else
   return -1;
}
char *SubStr(char *s1,int pos,int len)
{
    char *Result=new char;
    *Result='\0';
    char *Result_Array=new char[len];
    int LENGTH=0;
    for(int i=0;i<=LENGTH;i++)
    {
        if(s1[i]=='\0')
        {
            i=LENGTH+1;
        }
        else
        {
            LENGTH++;
        }
    }
    if(pos<=LENGTH){
    int end=0;
    for(int i=0;i<=LENGTH;i++)
    {
        if(end<len && i<LENGTH){
        Result_Array[end]=s1[pos+i];
        end++;
        }
        else if(LENGTH==i)
        {
            Result_Array[end]=*Result;
        }
    }
    return Result_Array;
    }
    else
    return Result;
}
