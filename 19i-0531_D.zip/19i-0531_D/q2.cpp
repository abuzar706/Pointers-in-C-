void countLetters(char *string,int *&array,int &size)
{
    int LENGTH=0;
    for(int i=0;i<=LENGTH;i++)
    {
        if(string[i]=='\0')
        {
            i=LENGTH+1;
        }
        else
        {
            LENGTH++;
        }
    }
    char *Duplicate = string;
    char setc;
    int INDEXES=0;
    bool *Confirmed=new bool[LENGTH];
    for(int i=0;i<LENGTH;i++)
    {
        Confirmed[i]=true;
    }
    for(int i=0;i<LENGTH;i++)
    {
        if(Confirmed[i]==true)
            {
                setc=Duplicate[i];
                //cout<<"ADDED : "<<setc<<endl;
                INDEXES++;
            //cout<<"Indexes : "<<INDEXES<<endl;
            }
        for(int j=0;j<LENGTH;j++)
        {
            if(setc==Duplicate[j] && Confirmed[j]==true)
            {
             Confirmed[j]=false;
            }
        }
    }
    //cout<<INDEXES<<endl;
    for(int i=0;i<LENGTH;i++)
        {
            Confirmed[i]=true;
        }
    array=new int[INDEXES];
    for(int i=0;i<INDEXES;i++)
    {
        array[i]=0;
    }
    int k=0;
    for(int i=0;i<LENGTH;i++)
    {
        if(Confirmed[i]==true && Duplicate[i]){
        setc=Duplicate[i];
        }
        for(int j=0;j<LENGTH;j++)
        {
            if(LENGTH-1==j && array[k]!=0)
            {
                k++;
            }
            if(setc==Duplicate[j] && Confirmed[j]==true)
            {
             array[k]++;
             Confirmed[j]=false;
            }
        }
    }
    size=INDEXES;
    delete []Confirmed;
}
void countWordsBasedOnLength(char *string,int *&array,int &size)
{
    int LENGTH=0;
    for(int i=0;i<=LENGTH;i++)
    {
        if(string[i]=='\0')
        {
            i=LENGTH+1;
        }
        else
        {
            LENGTH++;
        }
    }
    int TOTAL=0;
    int TOTALSPACE=0;
    for(int i=0;i<LENGTH;i++)
    {
        if(string[i]==' ')
        {
            TOTALSPACE++;
        }
    }
     for(int i=0;i<LENGTH;i++)
        {
            if(string[i]==' ' && string[i+1]!=' ' && i!=LENGTH-1)
            {
                TOTAL++;
            }
            else if(string[i]==' ' && i==LENGTH-1)
            {
                break;
            }
        }
        TOTAL+=1;
    int *WordsLength=new int[TOTAL];
    for(int i=0;i<TOTAL;i++)
    {
        WordsLength[i]=0;
    }
    int j=0;
    for(int i=0;i<LENGTH;i++)
    {
        if(string[i]==' ' && string[i+1] && string)
        {
            j++;
        }
        else
        {
            WordsLength[j]++;
        }

    }
    int temp=WordsLength[0];
    for(int i=0;i<TOTAL;i++)
    {
        for(int j=0;j<TOTAL;j++)
        {
            if(WordsLength[i]<WordsLength[j] && i!=j)
            {
                temp=WordsLength[i];
                WordsLength[i]=WordsLength[j];
                WordsLength[j]=temp;
            }
        }
    }
    temp=0;
    for(int i=0;i<TOTAL;i++)
    {
        if(temp<WordsLength[i])
        {
            temp=WordsLength[i];
        }
    }
    int *FINAL_ARRAY = new int[temp+1];
    FINAL_ARRAY[0]=TOTALSPACE;
    for(int i=1;i<temp+1;i++)
    {
        FINAL_ARRAY[i]=0;
    }
    for(int i=0;i<TOTAL;i++)
    {
        FINAL_ARRAY[WordsLength[i]]++;
    }

    int k=1;
        size=temp+1;
        array=FINAL_ARRAY;
        delete []WordsLength;
}
